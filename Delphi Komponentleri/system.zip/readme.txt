TSystem copyrigths by Steffen Forkmann

Zur Komponente gibs nicht viel zu sagen, das Beispiel verdeutlicht alle Funktionen.
Die Komponente ist as-is Freeware.

Servus.

www.delphinet.de.cx
mailto:forkmann@gmx.de


