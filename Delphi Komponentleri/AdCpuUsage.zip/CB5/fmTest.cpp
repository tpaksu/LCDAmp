//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "fmTest.h"
#include "adCpuUsage.hpp"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TTestForm *TestForm;
//---------------------------------------------------------------------------
__fastcall TTestForm::TTestForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TTestForm::LbAldynUrlClick(TObject *Sender)
{
    ShellExecute(Application->Handle, "open", "http://www.aldyn.ru/",
        NULL, NULL, SW_SHOWDEFAULT);
}
//---------------------------------------------------------------------------
void __fastcall TTestForm::FormCreate(TObject *Sender)
{
    int i;

    MInfo->Lines->Clear();

    MInfo->Lines->Add(Format("There are %d total CPU in your system",ARRAYOFCONST((GetCPUCount()))));

    for (i=0;  i < GetCPUCount(); i++) MInfo->Lines->Add("");
}
//---------------------------------------------------------------------------
void __fastcall TTestForm::TimerTimer(TObject *Sender)
{
    int i;

    CollectCPUData();

    MInfo->Lines->BeginUpdate();

    for(i=0; i < GetCPUCount(); i++)
        MInfo->Lines->Strings[i+1] = Format("CPU #%d - %5.2f%%",ARRAYOFCONST((i,GetCPUUsage(i)*100)));

    MInfo->Lines->EndUpdate();
}
//---------------------------------------------------------------------------
