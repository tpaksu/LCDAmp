//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("CpuUsageDemo.res");
USEFORM("fmTest.cpp", TestForm);
USEUNIT("..\adCpuUsage.pas");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
    try
    {
         Application->Initialize();
         Application->CreateForm(__classid(TTestForm), &TestForm);
         Application->Run();
    }
    catch (Exception &exception)
    {
         Application->ShowException(&exception);
    }
    return 0;
}
//---------------------------------------------------------------------------
