//---------------------------------------------------------------------------

#ifndef fmTestH
#define fmTestH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TTestForm : public TForm
{
__published:	// IDE-managed Components
        TLabel *LbAldynUrl;
        TMemo *MInfo;
        TTimer *Timer;
        void __fastcall LbAldynUrlClick(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
    void __fastcall TimerTimer(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TTestForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TTestForm *TestForm;
//---------------------------------------------------------------------------
#endif
